print('[selftest] PASS (skeleton)')
