Write-Host 'Lilith First Flight'; python tests/selftest.py
