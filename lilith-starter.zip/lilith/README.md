# Lilith Starter Repo

Version 0.1.0-alpha.1756840608

Run `python tests/selftest.py` to check.
