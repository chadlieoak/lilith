#!/usr/bin/env bash
echo 'Lilith First Flight'
python tests/selftest.py
